import{d as e}from"./index-Bbdv0Qkf.js";const o={async get(a){return(await e.get(`/seo/${a}`)).data.data},async update(a,t){return(await e.put(`/seo/${a}`,t)).data.data}};export{o as s};
